const Discord = require("discord.js")
const SlashCommands = require("../Handlers/slashCommands")
const config = require("../config")
const { ActivityType } = require("discord.js")

module.exports = async client => {

await SlashCommands(client)


  console.log(`\x1b[36m${client.user.tag} est bien en ligne\x1b[0m`);
  console.log(`\x1b[32m> [INVITE]: https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands\x1b[0m`);
  client.user.setStatus('dnd');
  console.log("--------->.<---------")

  console.log(`
\x1b[33m
  [ＭＡＤＥ]   [ＢＹ]   [ＸＶＱＨ]  
\x1b[0m
`);

    client.user.setActivity("Manager 0.0.1", {
      type: ActivityType.Custom,
      url : "https://twitch.tv/emilioottv"
    });

    client.user.setStatus('dnd');
}