const Discord = require("discord.js")

module.exports = {
    name: "ping",
    description: "affiche la latence du bot",
    options: [],

    async run(bot, message, args) {
        message.reply(`mon ping est ${bot.ws.ping}`)
    }
}