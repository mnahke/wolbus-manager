module.exports = {
    token: "", // Bot token
    dev: "", // L'id du dev/owner pour la cmd drop
    role: "", // Le role a donné quand un membre fait /createbot
    prefix: "!" // prefix (général) du gestion
}